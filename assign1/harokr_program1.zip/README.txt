To compile:
gcc --std=gnu99 -o movies movies.c

To execute:
./movies movie_sample_1.csv
